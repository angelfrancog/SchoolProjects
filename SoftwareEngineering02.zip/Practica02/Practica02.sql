SELECT * FROM ejerciciodos.productos;
SELECT * FROM productos WHERE Marca LIKE 'D%';
