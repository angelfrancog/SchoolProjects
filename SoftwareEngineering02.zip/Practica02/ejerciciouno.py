import mysql.connector
from faker import Faker
import random 

# Conectarse a la base de datos
conexion = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="ejerciciouno"
)
cursor = conexion.cursor()
fake = Faker()
##Llenar tabla clientes
def llenar_tabla(tabla, cantidad):
    durango_inserted = False  # Variable para verificar si ya se insertó un cliente de Durango

    for _ in range(cantidad):
        nombre = fake.name()
        domicilio = fake.street_address()
        ciudad = fake.city()
        estado = fake.state()
        codigo_postal = fake.zipcode()
        email = fake.email()

        if not durango_inserted and estado == "Durango":
            # Forzar un cliente de Durango
            estado = "Durango"
            durango_inserted = True

        insert_query = f"INSERT INTO {tabla} (Nombre, Domicilio, Ciudad, Estado, CodigoPostal, Email) VALUES (%s, %s, %s, %s, %s, %s)"
        cursor.execute(insert_query, (nombre, domicilio, ciudad, estado, codigo_postal, email))
    conexion.commit()
##Llenar tabla proveedores
def llenar_tabla2(tabla, cantidad):
    gmail_count = 0  #Proveedores con correo "@gmail"
    
    for _ in range(cantidad):
        empresa = fake.company()
        nombredelcontacto = fake.name()
        direccion = fake.street_address()
        ciudad = fake.city()
        estado = fake.state()
        codigo_postal = fake.zipcode()
        email = fake.email()

        if gmail_count < 5: #Asegura que haya al menos 5 proveedores con correo "@gmail"
            if not email.endswith("@gmail.com"):
                email = email.replace("@", "@gmail.")
            gmail_count += 1

        insert_query = f"INSERT INTO {tabla} (Empresa, Nombre_del_Contacto, Direccion, Ciudad, Estado, CodigoPostal, Email) VALUES (%s, %s, %s, %s, %s, %s, %s)"
        cursor.execute(insert_query, (empresa, nombredelcontacto, direccion, ciudad, estado, codigo_postal, email))

    conexion.commit()
##Llenar tabla productos
def llenar_tabla3(tabla, cantidad):
    productos_mayor_100_count = 0  #Productos con precio mayor a 100
    producto_15_50_inserted = False  

    for _ in range(cantidad):
        descripcion = fake.text(max_nb_chars=50)
        precio = round(random.uniform(1, 200), 2)  #Precio aleatorio entre 1 y 200
        marca = fake.company()
        existencia = random.randint(1, 100)

        #Asegura que haya al menos 3 productos con precio mayor a  100
        if precio > 100 and productos_mayor_100_count < 3:
            productos_mayor_100_count += 1

        #Asegura que haya al menos 1 producto con precio entre 15 y 50
        elif 15 <= precio <= 50 and not producto_15_50_inserted:
            producto_15_50_inserted = True

        insert_query = f"INSERT INTO {tabla} (Descripcion, Precio, Marca, Existencia) VALUES (%s, %s, %s, %s)"
        cursor.execute(insert_query, (descripcion, precio, marca, existencia))

    conexion.commit()
##Llenar tabla pedidos
def llenar_tabla4(tabla, cantidad):
    pedidos_total_mayor_200_count = 0  

    for _ in range(cantidad):
        numerodepedido = fake.unique.random_number(digits=6)
        vendedor = fake.name()
        fechadepedido = fake.date_between(start_date='-1y', end_date='today')
        producto = fake.word()
        cantidad = random.randint(1, 20)
        precio = round(random.uniform(10, 150), 2)  
        total = cantidad * precio

        #Asegura que haya al menos 4 pedidos con total mayor que 200 y cantidad mayor o igual a 10
        if total > 200 and cantidad >= 10 and pedidos_total_mayor_200_count < 4:
            pedidos_total_mayor_200_count += 1

        insert_query = f"INSERT INTO {tabla} (Numero_de_pedido, Vendedor, Fecha_de_Pedido, Producto, Cantidad, Precio, Total) VALUES (%s, %s, %s, %s, %s, %s, %s)"
        cursor.execute(insert_query, (numerodepedido, vendedor, fechadepedido, producto, cantidad, precio, total))

    conexion.commit()

# Create
def llenar_tablas():
    
    llenar_tabla("clientes", 15)
    llenar_tabla2("proveedores", 15)
    llenar_tabla3("productos", 15)
    llenar_tabla4("pedidos",15)

    print("Tablas llenadas automáticamente.")

# Read
def consulta_clientes_durango():
    
    cursor.execute("SELECT * FROM clientes WHERE Estado = 'Durango'")
    resultados = cursor.fetchall()
    if resultados:
        for resultado in resultados:
            print(resultado)
    else:
        print("No se encontraron clientes en Durango.")

def consulta_proveedores_gmail():
    
    cursor.execute("SELECT * FROM proveedores WHERE Email LIKE '%@gmail%' LIMIT 5")
    resultados = cursor.fetchall()
    if resultados:
        for resultado in resultados:
            print(resultado)
    else:
        print("No se encontraron proveedores con correo @gmail.")

def consulta_productos_precio_mayor_100():
    
    cursor.execute("SELECT * FROM productos WHERE Precio > 100 LIMIT 3")
    resultados = cursor.fetchall()
    if resultados:
        for resultado in resultados:
            print(resultado)
    else:
        print("No se encontraron productos con precio mayor a 100.")

def consulta_productos_precio_entre_15_y_50():
    
    cursor.execute("SELECT * FROM productos WHERE Precio BETWEEN 15 AND 50 LIMIT 1")
    resultados = cursor.fetchall()
    if resultados:
        for resultado in resultados:
            print(resultado)
    else:
        print("No se encontraron productos con precio entre 15 y 50.")

def consulta_pedidos_total_mayor_200_cantidad_10():
    
    cursor.execute("SELECT * FROM pedidos WHERE Total > 200 AND Cantidad >= 10 LIMIT 4")
    resultados = cursor.fetchall()
    if resultados:
        for resultado in resultados:
            print(resultado)
    else:
        print("No se encontraron pedidos con total mayor a 200 y cantidad mayor o igual a 10.")

def consulta_personalizada_proveedores():
    
    cursor.execute("SELECT * FROM proveedores WHERE Estado='Oregon'")  
    resultados = cursor.fetchall()
    if resultados:
        for resultado in resultados:
            print(resultado)
    else:
        print("No se encontraron proveedores en Oregon.")

#Update
def actualizar_datos():
    #Por alguna razon me arroja error si no pongo la conexion, host, user dentro de la funcion asi que lo adjunto de nuevo.
    try:
        conexion = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            database="ejerciciouno"
        )
        cursor = conexion.cursor()

        update_statements = [
            "UPDATE clientes SET Estado = 'Durango' WHERE id = 1",
            "UPDATE clientes SET Nombre = 'Angel' WHERE id = 2",
            "UPDATE clientes SET Nombre = 'Ivan' WHERE id = 3",
            "UPDATE clientes SET Ciudad = 'Tijuana' WHERE id = 4"
        ]

        for statement in update_statements:
            cursor.execute(statement)
            conexion.commit()

        cursor.execute("SELECT * FROM clientes WHERE id IN (1, 2, 3, 4)")
        registros_actualizados = cursor.fetchall()

        print("Registros actualizados:")
        for registro in registros_actualizados:
            print(registro)

        cursor.close()
        conexion.close()

        print("Datos actualizados exitosamente.")
    except mysql.connector.Error as error:
        print(f"Error al actualizar datos: {error}")

actualizar_datos()

#Delete
def eliminar_datos():
    #Por alguna razon me arroja error si no pongo la conexion, host, user dentro de la funcion asi que lo adjunto de nuevo.
    try:
        conexion = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            database="ejerciciouno"
        )
        cursor = conexion.cursor()

        delete_statements = [
            "DELETE FROM clientes WHERE id = 12",
            "DELETE FROM clientes WHERE id = 12",
            "DELETE FROM clientes WHERE id = 13",
            "DELETE FROM clientes WHERE id = 14",
            "DELETE FROM clientes WHERE id = 15"
        ]

        for statement in delete_statements:
            cursor.execute(statement)
            conexion.commit()

        print("Registros eliminados exitosamente.")

        cursor.close()
        conexion.close()
    except mysql.connector.Error as error:
        print(f"Error al eliminar datos: {error}")

eliminar_datos()

while True:
    print("\nMenú:")
    print("1. Create")
    print("2. Read")
    print("3. Update")
    print("4. Delete")
    print("5. Salir")

    opcion = input("Seleccione una opción: ")

    if opcion == "1":
        #Create
        llenar_tablas() 
    elif opcion == "2":
        # Read
        while True:
            print("\nConsultas:")
            print("1. Buscar clientes en Durango")
            print("2. Buscar proveedores con correo @gmail (al menos 5)")
            print("3. Buscar productos con precio mayor a 100 (al menos 3)")
            print("4. Buscar productos con precio entre 15 y 50 (al menos 1)")
            print("5. Buscar pedidos con total > 200 y cantidad >= 10 (al menos 4)")
            print("6. Consulta personalizada (proveedores)")
            print("7. Regresar al menú principal")

            consulta = input("Seleccione una consulta: ")

            if consulta == "1":
                consulta_clientes_durango()
            elif consulta == "2":
                consulta_proveedores_gmail()
            elif consulta == "3":
                consulta_productos_precio_mayor_100()
            elif consulta == "4":
                consulta_productos_precio_entre_15_y_50()
            elif consulta == "5":
                consulta_pedidos_total_mayor_200_cantidad_10()
            elif consulta == "6":
                consulta_personalizada_proveedores()
            elif consulta == "7":
                break
            else:
                print("Opción no válida.")
    elif opcion == "3":
        # Update
        actualizar_datos() 
    elif opcion == "4":
        # Delete
        eliminar_datos() 
    elif opcion == "5":
        break
    else:
        print("Opción no válida.")

cursor.close()
conexion.close()