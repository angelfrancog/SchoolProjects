from sqlalchemy import create_engine, Column, Integer, String, DateTime, Float, Boolean, or_, and_
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy import text
import random
from faker import Faker
from datetime import datetime
fake = Faker()
engine = create_engine('mysql+mysqlconnector://root:root@localhost/ejerciciodos')
Base = declarative_base()

# Define la clase de la tabla 'clientes'
class Cliente(Base):
    __tablename__ = 'clientes'
    id = Column(Integer, primary_key=True)
    Nombre = Column(String(50))
    Domicilio = Column(String(50))
    Ciudad = Column(String(50))
    Estado = Column(String(50))
    CodigoPostal = Column(String(5))
    Email = Column(String(50))    

# Define la clase de la tabla 'proveedores'
class Proveedor(Base):
    __tablename__ = 'proveedores'
    id = Column(Integer, primary_key=True)
    Empresa = Column(String(50))
    Nombre_del_Contacto = Column(String(50))
    Direccion = Column(String(50))
    Ciudad = Column(String(50))
    Estado = Column(String(50))
    CodigoPostal = Column(String(5))
    Email = Column(String(50))

# Define la clase de la tabla 'productos'
class ProductoC(Base):
    __tablename__ = 'productos'
    id = Column(Integer, primary_key=True)
    Descripcion = Column(String(50))
    Precio = Column(Float)
    Marca = Column(String(50))
    Existencia = Column(Integer)

# Define la clase de la tabla 'pedidos'
class Pedido(Base):
    __tablename__ = 'pedidos'
    id = Column(Integer, primary_key=True)
    Numero_de_pedido = Column(Integer)
    Vendedor = Column(String(50))
    Fecha_de_Pedido = Column(DateTime)
    Producto = Column(String(50))
    Cantidad = Column(Integer)
    Precio = Column(Float)
    Total = Column(Float)

Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
session = Session()

def llenar_tablas():
    fake = Faker()

        
# Llena la tabla 'clientes'
for _ in range(15):
    Nombre = fake.name()
    Domicilio = fake.address()
    Ciudad = fake.city()
    Estado = fake.state()
    CodigoPostal = fake.postcode()
    Email = fake.email()
    cliente_obj = Cliente(Nombre=Nombre, Domicilio=Domicilio, Ciudad=Ciudad, Estado=Estado, CodigoPostal=CodigoPostal, Email=Email)
    session.add(cliente_obj)        
        
        
        
    # Llena la tabla 'proveedores'
for _ in range(15):
    Empresa = fake.company()
    Nombre_del_Contacto = fake.name()
    Direccion = fake.address()
    Ciudad = fake.city()
    Estado = fake.state()
    CodigoPostal = fake.postcode()
    Email = fake.email()
    proveedor_obj = Proveedor(Empresa=Empresa, Nombre_del_Contacto=Nombre_del_Contacto, Direccion=Direccion, Ciudad=Ciudad, Estado=Estado, CodigoPostal=CodigoPostal, Email=Email)
    session.add(proveedor_obj)
        
    # Llena la tabla 'productos'
for _ in range(15):
    Descripcion = fake.word()
    Precio = round(random.uniform(10, 150), 2)
    Marca = fake.name()
    Existencia = random.randint(0, 1)
    producto_obj = ProductoC(Descripcion=Descripcion, Precio=Precio, Marca=Marca, Existencia=Existencia)
    session.add(producto_obj)


    # Llena la tabla 'pedidos'
for _ in range(15):
    Numero_de_pedido = random.randint(1, 1000)
    Vendedor = fake.name()
    Fecha_de_pedido = fake.date_between(start_date='-1y', end_date='today')
    Producto = fake.word()
    Cantidad = random.randint(1, 20)
    Precio = round(random.uniform(10, 150), 2)
    Total = Cantidad * Precio
    pedido_obj = Pedido(Numero_de_pedido=Numero_de_pedido, Vendedor=Vendedor, Fecha_de_Pedido=Fecha_de_pedido, Producto=Producto, Cantidad=Cantidad, Precio=Precio, Total=Total)
    session.add(pedido_obj)



    session.commit()

# Read (Consultas)

def consulta_clientes_nombre_comienza_con_letra_e():
    clientes = session.query(Cliente).filter(Cliente.Nombre.ilike('E%')).all()
    return clientes

def consulta_proveedores_correo_contiene_letra_a():
    proveedores = session.query(Proveedor).filter(Proveedor.Email.ilike('%a%')).all()
    return proveedores

def consulta_productos_con_existencia():
    productos = session.query(ProductoC).filter(ProductoC.Existencia > 0).all()
    return productos

def consulta_productos_marca_comienza_con_d():
    productosd = session.query(ProductoC).filter(ProductoC.Marca.ilike('D%')).all()
    return productosd

def consulta_pedidos_entre_fechas():
    fecha_inicio = datetime(2023, 1, 24)
    fecha_fin = datetime(2023, 4, 24)
    pedidos = session.query(Pedido).filter(and_(Pedido.Fecha_de_Pedido >= fecha_inicio, Pedido.Fecha_de_Pedido <= fecha_fin)).all()
    return pedidos

def consulta_personalizada_proveedores():
    proveedores = session.query(Proveedor).filter(Proveedor.Nombre_del_Contacto != 'John Doe').all()
    return proveedores
# Update
def actualizar_datos():
    # Actualizar 5 clientes a clientes preferenciales
    clientes_a_actualizar = session.query(Cliente).limit(5).all()

    if clientes_a_actualizar:
        for cliente in clientes_a_actualizar:
            nuevo_nombre = 'Clientes preferenciales' 
            cliente.Nombre = nuevo_nombre

            print(f'Registro cambiado - ID: {cliente.id}, Nuevo Nombre: {cliente.Nombre}')

        session.commit()
    else:
        print("No se encontraron clientes para actualizar.")


# Delete
def eliminar_datos():

    #  Eliminar 5 clientes
    clientes_a_eliminar = session.query(Cliente).limit(5).all()
    for cliente in clientes_a_eliminar:
        session.delete(cliente)
    session.commit()
    
    

while True:
    print("\nMenú:")
    print("1. Create (Llenar tablas automáticamente)")
    print("2. Read (Consultas)")
    print("3. Update (Actualizar datos)")
    print("4. Delete (Eliminar datos)")
    print("5. Salir")

    opcion = input("Seleccione una opción: ")

    if opcion == "1":
        llenar_tablas()
        print("Tablas llenadas automáticamente.")
    elif opcion == "2":
        while True:
            print("\nConsultas:")
            print("1. Buscar clientes cuyo nombre empiece con E")
            print("2. Buscar proveedores cuyo correo contenga al menos una letra a")
            print("3. Buscar productos con existencia")
            print("4. Buscar productos cuya marca empiece con D")
            print("5. Buscar pedidos cuya fecha esté entre 24/01/2023 y 24/04/2023")
            print("6. Consulta personalizada de proveedores")
            print("7. Regresar al menú principal")

            consulta = input("Seleccione una consulta: ")

            if consulta == "1":
                clientes = consulta_clientes_nombre_comienza_con_letra_e()
                for cliente in clientes:
                    print(f'ID: {cliente.id}, Nombre: {cliente.Nombre}, Email: {cliente.Email}')
            elif consulta == "2":
                proveedores = consulta_proveedores_correo_contiene_letra_a()
                for proveedor in proveedores:
                    print(f'ID: {proveedor.id}, Empresa: {proveedor.Empresa}, Email: {proveedor.Email}')
            elif consulta == "3":
                productos = consulta_productos_con_existencia()
                for producto in productos:
                    print(f'ID: {producto.id}, Descripción: {producto.Descripcion}, Existencia: {producto.Existencia}')
            elif consulta == "4":
                productos = consulta_productos_marca_comienza_con_d()
                for producto in productos:
                    print(f'ID: {producto.id}, Marca: {producto.Marca}, Descripción: {producto.Descripcion}')
            elif consulta == "5":
                pedidos = consulta_pedidos_entre_fechas()
                for pedido in pedidos:
                    print(f'ID: {pedido.id}, Fecha de Pedido: {pedido.Fecha_de_Pedido}, Total: {pedido.Total}')
            elif consulta == "6":
                proveedores = consulta_personalizada_proveedores()
                for proveedor in proveedores:
                    print(f'ID: {proveedor.id}, Nombre del Contacto: {proveedor.Nombre_del_Contacto}, Email: {proveedor.Email}')
            elif consulta == "7":
                break
            else:
                print("Opción no válida.")
    elif opcion == "3":
        actualizar_datos()
        print("Datos actualizados exitosamente.")
    elif opcion == "4":
        eliminar_datos()
        print("Datos eliminados exitosamente.")
    elif opcion == "5":
        break
    else:
        print("Opción no válida.")

session.close()
